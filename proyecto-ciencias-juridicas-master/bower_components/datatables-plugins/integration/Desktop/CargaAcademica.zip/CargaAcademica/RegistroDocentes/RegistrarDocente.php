
<?php 
	echo $_POST['identidad'];
 ?>