
<html lang="es">
    <head>
        <script type="text/javascript" src="jquery.js"></script>
        <script type="text/javascript">
            $(document).ready(function() {

                $("form").submit(//Se realiza cuando se ejecuta un "submit" en el formulario, el "submit" se encuentra en el boton "Envíar Solicitud
                    function(e) {
                        e.preventDefault();
                        var peticion = $('form').attr('action');
                        $.ajax({
                            async: true,
                            type: "POST",
                            // dataType: "html",
                            // contentType: "application/x-www-form-urlencoded",
                            url = peticion,
                            success: llegadaGuardar,
                            data: $('form').serialize(),
                            timeout: 4000,
                            error: problemas
                        }); //La función implemente ajax para enviar la información a otros 
                        //documentos que realizaran otros procedimientos sin necesidad de refrescar toda la pagina
                        return false;
                    }
                );
                function llegadaGuardar(datos)
                {
                    alert(datos);
                    $("#contenedor").load('pages/CargaAcademica/RegistroDocentes/RegristroDocentes.php',data);
                }
            });
            
        </script>
    </head>

<link href="css/datepicker.css" rel="stylesheet">
<link href="css/prettify.css" rel="stylesheet">
   
<script src="js/prettify.js"></script>
<script src="js/bootstrap-datepicker.js"></script>

            <body>
                  <form role="form" id="form" method="post" class="form-horizontal" action="pages/CargaAcademica/RegistroDocentes/RegistrarDocente.php">
                    <!-- .panel-heading -->
                    <div class="panel-body">
                        <h1>Información Personal de Docentes</h1></br>
                        <div class="panel-group" id="accordion">
                                <h1>Nuevo Docente</h1></br>
                                <div class="panel-group" id="accordion">
                                    <div class="panel panel-default">
                                        <div class="panel-heading">
                                            <h4 class="panel-title">
                                                <label><span class="glyphicon glyphicon-user" aria-hidden="true"></span> Datos Generales del Docente</label>
                                            </h4>
                                        </div>
                                        <div class="panel-body">
                                            <div class="col-lg-8">
                                                <div class="form-group">
                                                    <label class="col-sm-5 control-label"><span class="glyphicon glyphicon-exclamation-sign" aria-hidden="true"></span> Número de Identidad</label>
                                                    <div class="col-sm-7"><input id="identidad" class="form-control" name="identidad" placeholder="Ejemplo:0000-0000-00000" required pattern="[0-9]{4}[\-][0-9]{4}[\-][0-9]{5}"></div>
                                                </div>
                                                <div class="form-group">
                                                    <label class="col-sm-5 control-label"><span class="glyphicon glyphicon-exclamation-sign" aria-hidden="true"></span> Primer nombre</label>
                                                    <div class="col-sm-7"><input id="primerNombre" class="form-control" name="primerNombre" required></div>
                                                </div>
                                                <div class="form-group">
                                                    <label class="col-sm-5 control-label">Segundo nombre</label>
                                                    <div class="col-sm-7"><input id="segundoNombre" class="form-control" name="segundoNombre" ></div>
                                                </div>
                                                <div class="form-group">
                                                    <label class="col-sm-5 control-label"><span class="glyphicon glyphicon-exclamation-sign" aria-hidden="true"></span> Primer Apellido</label>
                                                    <div class="col-sm-7"><input id="primerApellido" class="form-control" name="primerApellido" required></div>
                                                </div>
                                                <div class="form-group">
                                                    <label class="col-sm-5 control-label"><span class="glyphicon glyphicon-exclamation-sign" aria-hidden="true"></span> Segundo Apellido</label>
                                                    <div class="col-sm-7"><input id="segundoApellido" class="form-control" name="segundoApellido" ></div>
                                                </div>
                                                <div class="form-group">
                                                    <label class="col-sm-5 control-label"><span class="glyphicon glyphicon-exclamation-sign" aria-hidden="true"></span>Telefono</label>
                                                    <div class="col-sm-7"><input id="telefono" class="form-control" name="telefono" required pattern="[0-9]{8}"></div>
                                                </div>
                                                <div class="form-group">
                                                    <label class="col-sm-5 control-label"><span class="glyphicon glyphicon-exclamation-sign" aria-hidden="true"></span>Titulo</label>

                                                    <div class="col-sm-7"><input id="titulo" class="form-control" name="titulo"></div>
                                                </div>
                                                <div class="form-group">
                                                    <label class="col-sm-5 control-label"></span>Ciudad Natal</label>
                                                    <div class="col-sm-7"><input id="CiudadNatal" class="form-control" name="ciudadNatal"></div>
                                                </div>
                                                <div class="form-group">
                                                    <label class="col-sm-5 control-label"><span class="glyphicon glyphicon-exclamation-sign" aria-hidden="true"></span>Correo Electronico</label>
                                                    <div class="col-sm-7"><input id="Correo" class="form-control" name="correo"></div>
                                                </div>
                                                <div class="form-group">
                                                    <label class="col-sm-5 control-label"><span class="glyphicon glyphicon-exclamation-sign" aria-hidden="true"></span> Sexo</label>
                                                    <input type="radio" name="sex" value="male">Masculino<br>
                                                    <input type="radio" name="sex" value="female">Feminino
                                                </div>
                                                <div class="form-group">
                                                    <label class="col-sm-5 control-label"><span class="glyphicon glyphicon-exclamation-sign" aria-hidden="true"></span> Nacionalidad</label>
                                                    <div class="col-sm-7"><select class="form-control" id="nacionalidad" name="nacionalidad"></select></div>
                                                        <br></br>
                                                </div>
                                                <div class="form-group">
                                                    <label class="col-sm-5 control-label"><strong><span class="glyphicon glyphicon-exclamation-sign" aria-hidden="true"></span> Fecha de Nacimiento</strong></label>
                                                    <div class="col-sm-7"><input id="fecha" type="date" name="fecha" autocomplete="off" class="input-xlarge" format="yyyy-mm-dd" required><br></div>
                                                </div>
                                                <div class="form-group">
                                                    <label class="col-sm-5 control-label"><span class="glyphicon glyphicon-exclamation-sign" aria-hidden="true"></span> Estado civil</label>
                                                    <div class="col-sm-7"><select class="form-control" id="estCivil" name="estCivil">
                                                                    <option>Soltero</option>
                                                                    <option>Casado</option>
                                                                    <option>Divorciado</option>
                                                                    <option>Viudo</option>
                                                                </select></div>
                                                                
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="alert alert-info" role="alert">IMPORTANTE: Los campos marcados con el signo <span class="glyphicon glyphicon-exclamation-sign" aria-hidden="true"></span> son obligatorios.</div>
                            </br><button type="submit" id="CrearDocente" class="ActualizarB btn btn-primary">Guardar Información</button>
                        </div>
                    </div>
                </form>
            </body>
</html>

